plumed sum_hills --hills ../HILLS --min 0.1 --max 0.8 --bin 300 --mintozero
